const express = require("express");
const http = require("http");
const PORT = process.env.PORT || 3000;

const app = express();
const server = http.createServer(app);
const io = require("socket.io")(server);

app.use(express.static("public"));

app.get("/", (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
});

app.get("/callpage",(req,res)=>{
    res.sendFile(__dirname + "/public/callpage.html");
})

let connectedPeers = [];

io.on("connection", (socket) => {

    connectedPeers.push(socket.id);

    socket.on("PreOffer", (data) => {
      const { strangerSocketId, calltype } = data;
      const connectedPeer = connectedPeers.find(
        (peerSocketId) => peerSocketId === strangerSocketId
      );
  
      if (connectedPeer) {
        const data = {
          callerSocketId: socket.id,
          calltype,
        };
        io.to(strangerSocketId).emit("PreOffer", data);
      } else {
          const data = {
            preOfferAnswer: "CALLEE_NOT_FOUND",
          };
          io.to(socket.id).emit("pre-offer-answer",data)
      }
    });
    socket.on("Pre-Offer-Answer", (data) => {
      const { callerSocketId } = data;
      const connectedPeer = connectedPeers.find(
        (peerSocketId) => peerSocketId === callerSocketId
      );
  
      if (connectedPeer) {
        io.to(data.callerSocketId).emit("Pre-Offer-Answer", data);
      }
    });
    socket.on("WebRTC-Signaling", (data) => {
        const { connectedUserSocketId } = data;
        const connectedPeer = connectedPeers.find(
          (peerSocketId) => peerSocketId === connectedUserSocketId
        );
    
        if (connectedPeer) {
          io.to(connectedUserSocketId).emit("WebRTC-Signaling", data);
        }
      });

    socket.on("Get-Stranger-Socket-Id", () => {
        let randomStrangerSocketId;
        const filteredConnectedPeers = connectedPeers.filter(
          (peerSocketId) => peerSocketId !== socket.id
        );
    
        if (filteredConnectedPeers.length > 0) {
          randomStrangerSocketId =
            filteredConnectedPeers[
              Math.floor(Math.random() * filteredConnectedPeers.length)
            ];
        } else {
          randomStrangerSocketId = null;
        }
        const data = {
          randomStrangerSocketId,
        };
        console.log("Server Stranger Socket Id "+ randomStrangerSocketId);
        io.to(socket.id).emit("stranger-socket-id", data);
    });
    socket.on("User-Hanged-Up", (data) => {
      const { connectedUserSocketId } = data;
  
      const connectedPeer = connectedPeers.find(
        (peerSocketId) => peerSocketId === connectedUserSocketId
      );
  
      if (connectedPeer) {
        io.to(connectedUserSocketId).emit("User-Hanged-Up");
      }
    });

    socket.on("disconnect", () => {
      console.log("User Disconnected");
      const newConnectedPeers = connectedPeers.filter(
        (peerSocketId) => peerSocketId !== socket.id
      );
      connectedPeers = newConnectedPeers;
      console.log(connectedPeers);
  });
});

server.listen(PORT, () => {
    console.log(`listening on ${PORT}`);
});