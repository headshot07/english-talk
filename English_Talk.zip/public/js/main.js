let call_animation = document.getElementById("call_animation");
call_animation.addEventListener('click', ()=> {
    window.location.href="/callpage";
})